package android.exampl.touriinjapan;

public class japan {
    private String mname;

    private int mimage;

    public japan(String name, int image) {
        mname = name;
        mimage = image;
    }


    public String getname() {

        return mname;

    }


    public int getimage() {
        return mimage;
    }

}
