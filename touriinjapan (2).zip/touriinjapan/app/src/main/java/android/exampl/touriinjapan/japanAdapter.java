package android.exampl.touriinjapan;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

public class japanAdapter extends ArrayAdapter<japan> {
    public japanAdapter(Activity context, ArrayList<japan> j) {

        super(context, 0, j);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View listItemView = convertView;
        if (listItemView == null) {
            listItemView = LayoutInflater.from(getContext()).inflate(
                    R.layout.list_item, parent, false);
        }
        japan currentplace = getItem(position);
        TextView name = (TextView) listItemView.findViewById(R.id.place);
        name.setText(currentplace.getname());
        ImageView image = (ImageView) listItemView.findViewById(R.id.image);
        image.setImageResource(currentplace.getimage());


        return listItemView;
    }
}

