package android.exampl.touriinjapan;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ListView;

import java.util.ArrayList;

public class kyoto extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.japan_list);
        ArrayList<japan> ja = new ArrayList<>();
        japanAdapter j = new japanAdapter(this, ja);
        j.add(new japan("Fushimi Inari Taisha", R.drawable.kfit));
        j.add(new japan("Kinkaku-ji", R.drawable.kk));
        j.add(new japan("Arashiyama", R.drawable.ka));
        ListView listView = (ListView) findViewById(R.id.list);

        listView.setAdapter(j);
    }
}