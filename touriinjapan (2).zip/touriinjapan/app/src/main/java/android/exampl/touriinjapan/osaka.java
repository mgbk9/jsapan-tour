package android.exampl.touriinjapan;

import android.os.Bundle;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.view.View;
import android.widget.ListView;

import java.util.ArrayList;

public class osaka extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.japan_list);
        ArrayList<japan> ja = new ArrayList<>();
        japanAdapter j = new japanAdapter(this, ja);
        j.add(new japan("Castle", R.drawable.oc));
        j.add(new japan("Dotonbori", R.drawable.od));
        j.add(new japan("Universal Studios Japan", R.drawable.ousj));
        j.add(new japan("Aquarium Kaiyukan", R.drawable.oak));
        j.add(new japan("Tsutenkaku", R.drawable.ot));
        ListView listView = (ListView) findViewById(R.id.list);

        listView.setAdapter(j);
    }
}