package android.exampl.touriinjapan;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ListView;

import java.util.ArrayList;

public class sapporo extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.japan_list);
        ArrayList<japan> ja = new ArrayList<>();
        japanAdapter j = new japanAdapter(this, ja);
j.add(new japan("Odori Park", R.drawable.sop));
        j.add(new japan("TV Tower", R.drawable.stt));
        j.add(new japan("Clock Tower", R.drawable.sct));
        ListView listView = (ListView) findViewById(R.id.list);

        listView.setAdapter(j);
    }
}