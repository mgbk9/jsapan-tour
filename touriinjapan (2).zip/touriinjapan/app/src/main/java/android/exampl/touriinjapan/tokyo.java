package android.exampl.touriinjapan;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ListView;

import java.util.ArrayList;

public class tokyo extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.japan_list);
        ArrayList<japan> ja = new ArrayList<>();
        japanAdapter j = new japanAdapter(this, ja);
        j.add(new japan("Skytree", R.drawable.ts));
        j.add(new japan("Sensō-ji", R.drawable.tsj));
        j.add(new japan("Meiji Jingu", R.drawable.tmj));
        j.add(new japan("Tower", R.drawable.td));
        j.add(new japan("Disneyland land", R.drawable.td));

        ListView listView = (ListView) findViewById(R.id.list);

        listView.setAdapter(j);
    }
}